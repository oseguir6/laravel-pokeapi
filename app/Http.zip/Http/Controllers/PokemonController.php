<?php

namespace App\Http\Controllers;

use App\Models\Pokemon;
use Illuminate\Http\Request;

class PokemonController extends Controller
{
    // Obtener la lista de todos los Pokémon con sus relaciones (types, abilities, stats, etc.)
public function index()
{
    // Obtener todos los Pokémon
    $pokemons = Pokemon::all();
    return response()->json([
        "success" => true,
        "data" => $pokemons
    ]);

    // En el código original parece que intentabas retornar dos veces. La segunda línea nunca se ejecutaría.
    // Si necesitas incluir más datos con relaciones, puedes hacerlo descomentando lo siguiente:
    // $pokemons = Pokemon::with(['types', 'abilities', 'stats', 'moves', 'gameIndices', 'heldItems', 'forms'])->get();
    // return response()->json($pokemons);
}


    // Obtener un Pokémon específico por su ID con todas sus relaciones
    public function show($id)
    {
        $pokemon = Pokemon::with(['types', 'abilities', 'stats', 'moves', 'gameIndices', 'heldItems', 'forms'])->findOrFail($id);
        return response()->json($pokemon);
    }

    // Crear un nuevo Pokémon
    public function store(Request $request)
    {
        // Validar los datos que vienen del request
        $validated = $request->validate([
            'name' => 'required|string',
            'image' => 'required|string',
            'height' => 'required|numeric',
            'weight' => 'required|numeric',
            'base_experience' => 'required|integer',
            'habitat' => 'nullable|string',
            'back_color' => 'required|string',
        ]);

        // Crear un nuevo Pokémon con los datos validados
        $pokemon = Pokemon::create($validated);

        // Si tienes que asociar tipos, habilidades, etc.:
        if ($request->has('types')) {
            $pokemon->types()->attach($request->types);
        }

        if ($request->has('abilities')) {
            $pokemon->abilities()->attach($request->abilities);
        }

        if ($request->has('stats')) {
            foreach ($request->stats as $stat) {
                $pokemon->stats()->create($stat);
            }
        }

        if ($request->has('moves')) {
            $pokemon->moves()->attach($request->moves);
        }

        if ($request->has('gameIndices')) {
            $pokemon->gameIndices()->attach($request->gameIndices);
        }

        if ($request->has('heldItems')) {
            $pokemon->heldItems()->attach($request->heldItems);
        }

        if ($request->has('forms')) {
            $pokemon->forms()->attach($request->forms);
        }

        return response()->json($pokemon, 201); // 201: Resource created
    }

    // Actualizar un Pokémon
    public function update(Request $request, $id)
    {
        $pokemon = Pokemon::findOrFail($id);

        // Validar los datos que vienen del request
        $validated = $request->validate([
            'name' => 'sometimes|string',
            'image' => 'sometimes|string',
            'height' => 'sometimes|numeric',
            'weight' => 'sometimes|numeric',
            'base_experience' => 'sometimes|integer',
            'habitat' => 'nullable|string',
            'back_color' => 'sometimes|string',
        ]);

        // Actualizar el Pokémon con los datos validados
        $pokemon->update($validated);

        // Si tienes que actualizar tipos, habilidades, etc.
        if ($request->has('types')) {
            $pokemon->types()->sync($request->types);
        }

        if ($request->has('abilities')) {
            $pokemon->abilities()->sync($request->abilities);
        }

        if ($request->has('stats')) {
            $pokemon->stats()->delete(); // Eliminar estadísticas anteriores
            foreach ($request->stats as $stat) {
                $pokemon->stats()->create($stat);
            }
        }

        if ($request->has('moves')) {
            $pokemon->moves()->sync($request->moves);
        }

        if ($request->has('gameIndices')) {
            $pokemon->gameIndices()->sync($request->gameIndices);
        }

        if ($request->has('heldItems')) {
            $pokemon->heldItems()->sync($request->heldItems);
        }

        if ($request->has('forms')) {
            $pokemon->forms()->sync($request->forms);
        }

        return response()->json($pokemon);
    }

    // Eliminar un Pokémon
    public function destroy($id)
    {
        $pokemon = Pokemon::findOrFail($id);
        $pokemon->delete();

        return response()->json(null, 204); // 204: No content
    }
}
