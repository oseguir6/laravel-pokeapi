<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HabilitatsController extends Controller
{
    //
}
