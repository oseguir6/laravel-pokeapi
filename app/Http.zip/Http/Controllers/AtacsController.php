<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AtacsController extends Controller
{
    //
}
